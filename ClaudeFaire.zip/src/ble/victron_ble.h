#pragma once
/*
 * victron_ble.h - Module Victron via BLE Advertisement (NimBLE)
 * Base : Fabian-Schmidt/esphome-victron_ble
 * Protocol : Victron "Instant readout" - AES-128-CTR chiffre
 *
 * Appareils geres :
 *   - SmartSolar MPPT  (CF:A0:F0:EF:C4:39)
 *   - SmartBMV 712     (C5:9F:63:D2:E7:45)
 *   - BatteryProtect   (E5:7A:2C:1C:D4:0C)
 *   - OrionSmart DC-DC (DE:5F:86:D7:15:E3)
 */
#include <Arduino.h>
#include <NimBLEDevice.h>
#include "bluetooth_config.h"
#include "ble/victron_ble.h"
#include "ble/jkbms_ble.h"
#include "ble/heating_ble.h"

// ============================================================
//  Donnees MPPT (Solar Charger - SmartSolar)
// ============================================================
struct VictronMpptData {
    float    pv_voltage;
    float    pv_current;
    float    pv_power;
    float    battery_voltage;
    float    battery_current;
    float    charge_power;
    float    yield_today;
    float    yield_total;
    uint8_t  device_state;
    uint8_t  charger_error;
    bool     connected;
    bool     data_valid;
    uint32_t last_update_ms;
};

// ============================================================
//  Donnees SmartShunt
// ============================================================
struct VictronSmartshuntData {
    float    current;
    float    power;
    float    consumed_ah;
    float    soc;
    float    time_to_go;
    bool     alarm;
    uint16_t alarm_reason;
    bool     connected;
    bool     data_valid;
    uint32_t last_update_ms;
};

// ============================================================
//  Donnees SmartBMV 712
// ============================================================
struct VictronBmvData {
    float    battery_voltage;
    float    battery_current;
    float    battery_power;
    float    soc;
    float    time_to_go;
    float    consumed_ah;
    float    aux_voltage;
    float    aux_temperature;
    bool     aux_is_temperature;
    uint32_t charge_cycles;
    uint32_t full_charges;
    float    deepest_discharge_ah;
    float    last_discharge_ah;
    float    average_discharge_ah;
    float    cumulative_ah;
    bool     relay_state;
    bool     alarm;
    uint16_t alarm_reason;
    int8_t   trend;
    bool     connected;
    bool     data_valid;
    uint32_t last_update_ms;
};

typedef VictronBmvData VictronShuntData;

// ============================================================
//  Donnees BatteryProtect
// ============================================================
struct VictronBpData {
    float    input_voltage;
    float    output_voltage;
    uint8_t  device_state;
    bool     alarm;
    uint16_t alarm_reason;
    bool     connected;
    bool     data_valid;
    uint32_t last_update_ms;
};

// ============================================================
//  Donnees OrionSmart DC-DC
// ============================================================
struct VictronOrionData {
    float    input_voltage;
    float    output_voltage;
    float    output_current;
    float    output_power;
    uint8_t  device_state;
    bool     connected;
    bool     data_valid;
    uint32_t last_update_ms;
};

// ============================================================
//  Structure interne paquet Victron
// ============================================================
#pragma pack(push, 1)
struct VictronBleRecordBase {
    uint8_t  manufacturer_record_type;
    uint8_t  unknown;
    uint16_t model_id;
    uint8_t  readout_type;
    uint16_t record_id;
    uint8_t  encryption_key_0;
};
#pragma pack(pop)

#define VICTRON_ENCRYPTED_DATA_MAX_SIZE  16

// ============================================================
//  Callbacks
// ============================================================
class VictronScanCallbacks : public NimBLEAdvertisedDeviceCallbacks {
public:
    void onResult(NimBLEAdvertisedDevice* advertisedDevice) override;
};

// ============================================================
//  Classe VictronBle
// ============================================================
class VictronBle {
public:
    VictronBle();
    void begin();
    void update();

    const VictronMpptData&        getMpptData()       const { return _mppt;       }
    const VictronSmartshuntData&  getSmartshuntData() const { return _smartshunt; }
    const VictronBmvData&         getBmvData()        const { return _bmv;        }
    const VictronBpData&          getBpData()         const { return _bp;         }
    const VictronOrionData&       getOrionData()      const { return _orion;      }
    const VictronBmvData&         getShuntData()      const { return _bmv;        }

    static VictronBle* instance;
    void onAdvertisement(NimBLEAdvertisedDevice* device);

private:
    enum DeviceType { DEV_MPPT, DEV_SMARTSHUNT, DEV_BMV, DEV_BP, DEV_ORION };

    void _parseAdvertisement(NimBLEAdvertisedDevice* device,
                             const uint8_t* bindkey, DeviceType type);
    bool _decrypt(const uint8_t* payload, size_t payloadLen,
                  const uint8_t* bindkey,
                  const uint8_t* mac,
                  uint16_t record_id,
                  uint8_t* outData, size_t outLen);
    void _hexToBytes(const char* hexStr, uint8_t* bytes, size_t len);
    void _parseSolarCharger(const uint8_t* data);
    void _parseSmartshunt(const uint8_t* data);
    void _parseBatteryMonitor(const uint8_t* data);
    void _parseBatteryProtect(const uint8_t* data);
    void _parseOrionSmart(const uint8_t* data);
    const char* _stateToString(uint8_t state);

    VictronMpptData       _mppt;
    VictronSmartshuntData _smartshunt;
    VictronBmvData        _bmv;
    VictronBpData         _bp;
    VictronOrionData      _orion;
    VictronScanCallbacks  _scanCbs;
    uint32_t              _lastScanMs;
};

extern VictronBle victronBle;