// GG Van Dashboard — main.cpp
// ESP32-S3 + Waveshare 7B 1024x600 + LVGL
// BLE : JKBMS + Victron + Chauffage
// WiFi : NTP + OpenWeatherMap + BME280

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <NTPClient.h>
#include <esp_task_wdt.h>
#include <esp_display_panel.hpp>
#include <lvgl.h>
#include "lvgl_v8_port.h"

#include "config.h"

// ─── Modules ────────────────────────────────────────────────────────────────
#include "ble/jkbms_ble.h"
#include "ble/victron_ble.h"
#include "ble/heating_ble.h"
#include "weather/weather.h"
#include "weather/bme280_sensor.h"
#include "water/water_level.h"
#include "gps/gps.h"

// ─── UI ─────────────────────────────────────────────────────────────────────
#include "ui/ui.h"
#include "ui/lvgl_anim_icons.h"
#include "ui/pir_sensor.h"
#include "ui/page_weather.h"
#include "ui/page_dashboard_7.h"

// Forward declaration (van_ui_anim_init.cpp)
void van_anims_init(void);

// ─── Constantes ─────────────────────────────────────────────────────────────
#define WDT_TIMEOUT_SEC   30
#define WIFI_MAX_RETRIES   3

// ─── Timers ─────────────────────────────────────────────────────────────────
static uint32_t t_weather_update = 0;
static uint32_t t_ntp_update     = 0;
static uint32_t t_clock_update   = 0;
static uint32_t t_ble_update     = 0;
static uint8_t  wifi_retry_count = 0;

WeatherManager weather;
WiFiUDP        ntp_udp;
NTPClient      ntp_client(ntp_udp, NTP_SERVER, NTP_GMT_OFFSET + NTP_DST_OFFSET);

// ─── WiFi ────────────────────────────────────────────────────────────────────
static void wifi_connect() {
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("[WiFi] Deja connecte");
        van_anim_set_wifi(true);
        return;
    }
    Serial.printf("[WiFi] Connexion a %s (tentative %d/%d)...\n",
                  WIFI_SSID, wifi_retry_count + 1, WIFI_MAX_RETRIES);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    for (uint8_t i = 0; i < 20 && WiFi.status() != WL_CONNECTED; i++) {
        delay(500);
        esp_task_wdt_reset();
        Serial.print(".");
    }
    bool ok = (WiFi.status() == WL_CONNECTED);
    if (ok) {
        wifi_retry_count = 0;
        Serial.printf("\n[WiFi] OK - IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        wifi_retry_count++;
        Serial.printf("\n[WiFi] Echec tentative %d/%d\n", wifi_retry_count, WIFI_MAX_RETRIES);
    }
    van_anim_set_wifi(ok);
}

// ─── Setup ───────────────────────────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println("[GG_Dashboard] Demarrage Waveshare 7B...");

    // Watchdog
    esp_task_wdt_init(WDT_TIMEOUT_SEC, true);
    esp_task_wdt_add(NULL);
    Serial.println("[WDT] Watchdog 30s actif");

    // BME280 (I2C)
    weather.begin();

    // Relais OFF par defaut
    const uint8_t relay_pins[] = {
        RELAY_LIGHT1, RELAY_LIGHT2, RELAY_LIGHT3,
        RELAY_LIGHT4, RELAY_LIGHT5, RELAY_LIGHT6,
        RELAY_TV, RELAY_WATER_PUMP, RELAY_WATER_HEATER
    };
    for (auto p : relay_pins) {
        pinMode(p, OUTPUT);
        digitalWrite(p, RELAY_OFF);
    }

    // LVGL + ecran Waveshare 7B
    ui.begin();

    // PIR (retro-eclairage auto)
    pir_sensor_init(
        []() { Serial.println("[PIR] Ecran ON"); },
        []() { Serial.println("[PIR] Ecran OFF (veille)"); }
    );

    // BLE
    jkBms.begin();
    victronBle.begin();
    heatingBle.begin();
    van_anim_set_ble(false);

    // WiFi + NTP
    wifi_connect();
    ntp_client.begin();
    ntp_client.update();

    // Meteo OpenWeatherMap initiale
    weather_init();
    weather_update();
    if (weatherData.valid) {
        van_anim_set_weather(0, owm_to_anim_code(weatherData.days[0].owm_id));
        van_anim_set_weather(1, owm_to_anim_code(weatherData.days[1].owm_id));
        van_anim_set_weather(2, owm_to_anim_code(weatherData.days[2].owm_id));
    }

    // GPS + eau
    gps_init();
    water_level_init();

    // Animations LVGL
    van_anims_init();

    Serial.println("[GG_Dashboard] PRET");
}

// ─── Loop ────────────────────────────────────────────────────────────────────
void loop() {
    uint32_t now = millis();

    // BME280
    weather.update();

    // BLE
    jkBms.update();
    victronBle.update();
    heatingBle.update();

    // Eau + GPS
    water_level_update();
    gps_update();

    // PIR
    if (pir_sensor_update()) {
        if (pir_get_screen_state() == SCREEN_STATE_ON) {
            page_dashboard_7_update();
        }
    }

    // LVGL
    lv_timer_handler();

    // Dashboard 7" (mise a jour continue)
    page_dashboard_7_update();

    // Page meteo si visible
    if (ui.currentPage() == PAGE_WEATHER) {
        page_weather_update();
    }

    // Watchdog
    esp_task_wdt_reset();

    // BLE -> animations (toutes les 2s)
    if (now - t_ble_update >= UI_BLE_UPDATE_MS) {
        t_ble_update = now;
        bool ble_ok = jkBms.isConnected();
        van_anim_set_ble(ble_ok);
        if (ble_ok) {
            const JkBmsData& d = jkBms.getData();
            van_anim_set_battery_charging(d.battery_current > 0.0f);
        }
        if (ui.currentPage() == PAGE_BATTERY) page_battery_update();
        if (ui.currentPage() == PAGE_HOME)    page_home_update();
    }

    // Horloge (toutes les 1s)
    if (now - t_clock_update >= UI_CLOCK_UPDATE_MS) {
        t_clock_update = now;
        ntp_client.update();
        if (ui.currentPage() == PAGE_HOME)   page_home_update();
        if (ui.currentPage() == PAGE_SYSTEM) page_system_update();
        page_heating_update();
    }

    // Meteo OWM (toutes les 10 min)
    if (now - t_weather_update >= UPDATE_PERIOD_WEATHER_MS) {
        t_weather_update = now;
        if (WiFi.status() == WL_CONNECTED) {
            weather_update();
            if (weatherData.valid) {
                van_anim_set_weather(0, owm_to_anim_code(weatherData.days[0].owm_id));
                van_anim_set_weather(1, owm_to_anim_code(weatherData.days[1].owm_id));
                van_anim_set_weather(2, owm_to_anim_code(weatherData.days[2].owm_id));
            }
        }
    }

    // Reconnexion WiFi (toutes les heures)
    if (now - t_ntp_update >= UPDATE_PERIOD_NTP_MS) {
        t_ntp_update = now;
        if (WiFi.status() != WL_CONNECTED) wifi_connect();
        van_anim_set_wifi(WiFi.status() == WL_CONNECTED);
    }

    delay(5);
}