#include "bme280_history.h"
#include <Arduino.h>

void BME280History::addSample(float temp, float hum, float press) {
    buffer[index] = { millis(), temp, hum, press };
    index = (index + 1) % MAX_SAMPLES;
    if (count < MAX_SAMPLES) count++;
}

float BME280History::getMinTemp() const {
    if (count == 0) return 0.0f;
    float minVal = buffer[0].temperature;
    for (uint8_t i = 1; i < count; i++)
        if (buffer[i].temperature < minVal) minVal = buffer[i].temperature;
    return minVal;
}

float BME280History::getMaxTemp() const {
    if (count == 0) return 0.0f;
    float maxVal = buffer[0].temperature;
    for (uint8_t i = 1; i < count; i++)
        if (buffer[i].temperature > maxVal) maxVal = buffer[i].temperature;
    return maxVal;
}

float BME280History::getTempTrend() const {
    if (count < 2) return 0.0f;
    uint8_t last  = (index + MAX_SAMPLES - 1) % MAX_SAMPLES;
    uint8_t older = (count >= 6) ? (index + MAX_SAMPLES - 6) % MAX_SAMPLES : 0;
    return buffer[last].temperature - buffer[older].temperature;
}
