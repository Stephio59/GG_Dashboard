#include "bme280_alerts.h"
#include "../display_config.h"
#include <Arduino.h>

void BME280Alerts::check(float temp, float humidity, float pressure, float dewPoint) {
    uint32_t now = millis();
    float dewMargin = temp - dewPoint;

    alerts[0].active = (temp      <= BME_FREEZE_TEMP_C);
    alerts[1].active = (dewMargin <  CONDENSATION_MARGIN);
    alerts[2].active = (humidity  >= BME_HIGH_HUMIDITY_PCT);
    alerts[3].active = (pressure  <= BME_LOW_PRESSURE_HPA);
    alerts[4].active = (temp      >= BME_HIGH_TEMP_C);

    for (auto& a : alerts) {
        if (a.active && a.triggeredAt == 0) a.triggeredAt = now;
        else if (!a.active)                 a.triggeredAt = 0;
    }
}

Alert* BME280Alerts::getActiveAlerts(uint8_t& count) {
    static Alert active[5];
    count = 0;
    for (auto& a : alerts)
        if (a.active) active[count++] = a;
    return active;
}

void BME280Alerts::acknowledge(AlertType type) {
    for (auto& a : alerts)
        if (a.type == type) { a.active = false; a.triggeredAt = 0; }
}
